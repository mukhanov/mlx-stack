"""Small helpers: colored output, hardware, formatting."""
import platform
import subprocess


def info(msg: str) -> None:
    print(f"\033[1;34m== {msg}\033[0m")


def ok(msg: str) -> None:
    print(f"\033[1;32m   {msg}\033[0m")


def warn(msg: str) -> None:
    print(f"\033[1;33m   {msg}\033[0m")


def total_ram_gb() -> int:
    """Total machine RAM in GB (macOS: hw.memsize is in bytes)."""
    try:
        out = subprocess.run(
            ["sysctl", "-n", "hw.memsize"], capture_output=True, text=True
        )
        return int(out.stdout.strip()) // 1024**3
    except Exception:
        return 8


def gpu_name() -> str:
    """Chip name for the header — the real one on Apple Silicon
    (machdep.cpu.brand_string, e.g. "Apple M5 Max": llmfit scoring keys its
    memory-bandwidth table off this string)."""
    try:
        out = subprocess.run(
            ["sysctl", "-n", "machdep.cpu.brand_string"],
            capture_output=True, text=True,
        )
        if out.stdout.strip():
            return out.stdout.strip()
    except Exception:
        pass
    return "Apple Silicon" if platform.machine() == "arm64" else "Intel/Other"


def human_bytes(n: float) -> str:
    for u in "BKMG":
        if n < 1024 or u == "G":
            return f"{n:.1f}{u}" if u == "G" else f"{n:.0f}{u}"
        n /= 1024
